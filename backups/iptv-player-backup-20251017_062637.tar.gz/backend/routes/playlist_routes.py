from flask import Blueprint, request, jsonify
import os
from werkzeug.utils import secure_filename
from models.playlist import get_session, Playlist, Channel
from parsers.m3u_parser import M3UParser
from parsers.xtream_parser import XtreamParser
from parsers.stalker_parser import StalkerParser

playlist_bp = Blueprint("playlist", __name__)

@playlist_bp.route("", methods=["GET"])
def get_playlists():
    """Get all playlists"""
    session = get_session()
    try:
        playlists = session.query(Playlist).all()
        return jsonify([{
            "id": p.id,
            "name": p.name,
            "source_type": p.source_type,
            "playlist_type": p.playlist_type,
            "last_updated": p.last_updated.isoformat() if p.last_updated else None,
            "channel_count": len(p.channels),
        } for p in playlists])
    finally:
        session.close()

@playlist_bp.route("", methods=["POST"])
def add_playlist():
    """Add a new playlist and parse its channels"""
    data = request.get_json(force=True)
    session = get_session()
    
    try:
        playlist = Playlist(
            name=data["name"],
            source_type=data["source_type"],
            source_url=data.get("source_url"),
            file_path=data.get("file_path"),
            playlist_type=data.get("playlist_type", "m3u"),
            user_agent=data.get("user_agent"),
            xtream_username=data.get("xtream_username"),
            xtream_password=data.get("xtream_password"),
            stalker_mac=data.get("stalker_mac"),
            auto_update=data.get("auto_update", True),
        )
        session.add(playlist)
        session.flush()  # Get the playlist ID before parsing
        
        print(f"=== Adding playlist: {playlist.name} (ID: {playlist.id}) ===")
        print(f"Type: {playlist.playlist_type}, Source: {playlist.source_type}")
        
        channels = []
        pt = (data.get("playlist_type") or "m3u").lower()
        st = (data.get("source_type") or "url").lower()

        if pt in ("m3u", "m3u8"):
            parser = M3UParser(user_agent=data.get("user_agent"))
            
            try:
                if st == "url":
                    print(f"Parsing from URL: {data['source_url']}")
                    channels = parser.parse_from_url(data["source_url"])
                elif st == "file":
                    if not data.get("file_path"):
                        raise ValueError("file_path is required for file uploads")
                    print(f"Parsing from file: {data['file_path']}")
                    channels = parser.parse_from_file(data["file_path"])
                else:
                    raise ValueError(f"Invalid source_type: {st}")
                    
                print(f"Parser returned {len(channels)} channels")
                
            except Exception as parse_error:
                print(f"ERROR parsing playlist: {parse_error}")
                import traceback
                traceback.print_exc()
                session.rollback()
                return jsonify({"error": f"Failed to parse playlist: {str(parse_error)}"}), 500

        elif pt == "xtream":
            parser = XtreamParser(
                data["source_url"],
                data["xtream_username"],
                data["xtream_password"],
            )
            channels = parser.get_live_streams()

        elif pt == "stalker":
            parser = StalkerParser(data["source_url"], data["stalker_mac"])
            genres = parser.get_genres()
            js = genres.get("js") or {}
            genre_items = js.get("data") or js if isinstance(js, list) else []
            for g in genre_items:
                gid = g.get("id") or "*"
                channels.extend(parser.get_channels(gid))

        # Add channels to database
        print(f"Adding {len(channels)} channels to database...")
        for idx, ch in enumerate(channels):
            try:
                channel = Channel(
                    playlist_id=playlist.id,
                    name=ch.get("name", ""),
                    group_title=ch.get("group_title", ""),
                    tvg_id=ch.get("tvg_id", ""),
                    tvg_name=ch.get("tvg_name", ""),
                    tvg_logo=ch.get("tvg_logo", ""),
                    stream_url=ch.get("stream_url", ""),
                    catchup=ch.get("catchup", ""),
                    catchup_source=ch.get("catchup_source", ""),
                    catchup_days=ch.get("catchup_days", 0),
                    channel_number=ch.get("channel_number"),
                )
                session.add(channel)
                
                if idx % 100 == 0 and idx > 0:
                    print(f"Added {idx} channels...")
                    
            except Exception as ch_error:
                print(f"Error adding channel {idx}: {ch_error}")
                continue

        session.commit()
        print(f"=== Successfully added playlist with {len(channels)} channels ===")
        
        return jsonify({
            "id": playlist.id,
            "name": playlist.name,
            "channel_count": len(channels)
        }), 201
        
    except Exception as e:
        session.rollback()
        print(f"ERROR adding playlist: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()

@playlist_bp.route("/<int:playlist_id>", methods=["DELETE"])
def delete_playlist(playlist_id):
    """Delete a playlist and all its channels"""
    session = get_session()
    try:
        playlist = session.query(Playlist).get(playlist_id)
        if not playlist:
            return jsonify({"error": "Playlist not found"}), 404
        
        session.delete(playlist)
        session.commit()
        return jsonify({"message": "Playlist deleted successfully"})
    finally:
        session.close()

@playlist_bp.route("/upload", methods=["POST"])
def upload_playlist():
    """Upload M3U file and return the saved filepath"""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    save_dir = os.path.abspath("./data/playlists")
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, filename)

    try:
        # Read and save as UTF-8 to avoid encoding issues
        raw = file.read()
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            # Fallback to latin-1 for extended ASCII
            text = raw.decode("latin-1")
        
        with open(save_path, "w", encoding="utf-8") as out:
            out.write(text)
        
        print(f"Uploaded file saved to: {save_path}")
        
        return jsonify({
            "filename": filename,
            "filepath": save_path
        }), 200
        
    except Exception as e:
        print(f"Upload error: {e}")
        return jsonify({"error": f"Failed to save file: {str(e)}"}), 500
