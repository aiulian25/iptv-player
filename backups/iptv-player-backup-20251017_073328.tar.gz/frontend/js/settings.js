// Load user profile
async function loadProfile() {
    try {
        const response = await fetch(`${API_BASE}/auth/profile`, {
            credentials: 'include'
        });
        
        if (response.status === 401) {
            window.location.href = '/login.html';
            return;
        }
        
        const user = await response.json();
        document.getElementById('current-username').textContent = user.username;
        
    } catch (error) {
        console.error('Error loading profile:', error);
        showAlert('Failed to load profile', 'error');
    }
}

// Change username form
document.getElementById('change-username-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const newUsername = document.getElementById('new-username').value;
    const password = document.getElementById('username-password').value;
    
    if (newUsername.length < 3) {
        showAlert('Username must be at least 3 characters', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/auth/change-username`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ 
                new_username: newUsername,
                password: password
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showAlert('Username changed successfully!', 'success');
            document.getElementById('current-username').textContent = data.username;
            document.getElementById('change-username-form').reset();
        } else {
            showAlert(data.error || 'Failed to change username', 'error');
        }
    } catch (error) {
        console.error('Change username error:', error);
        showAlert('Failed to change username', 'error');
    }
});

// Change password form
document.getElementById('change-password-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const currentPassword = document.getElementById('current-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    if (newPassword !== confirmPassword) {
        showAlert('New passwords do not match', 'error');
        return;
    }
    
    if (newPassword.length < 8) {
        showAlert('Password must be at least 8 characters', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/auth/change-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ 
                current_password: currentPassword,
                new_password: newPassword
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showAlert('Password changed successfully!', 'success');
            document.getElementById('change-password-form').reset();
        } else {
            showAlert(data.error || 'Failed to change password', 'error');
        }
    } catch (error) {
        console.error('Change password error:', error);
        showAlert('Failed to change password', 'error');
    }
});

function showAlert(message, type = 'error') {
    const container = document.getElementById('alert-container');
    container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    
    // Auto-hide success messages after 5 seconds
    if (type === 'success') {
        setTimeout(() => {
            container.innerHTML = '';
        }, 5000);
    }
}

// Load profile on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadProfile);
} else {
    loadProfile();
}
