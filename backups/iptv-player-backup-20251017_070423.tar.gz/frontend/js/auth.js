const API_BASE = '/api';

let currentUser = null;

// Check auth status on page load
async function checkAuth() {
    // Only run on main app page
    if (window.location.pathname === '/login.html' || window.location.pathname === '/change-password.html') {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/auth/status`, {
            credentials: 'include'
        });
        const data = await response.json();
        
        currentUser = data.authenticated ? data : null;
        
        // Show protected UI elements only if authenticated
        updateUIBasedOnAuth(data.authenticated);
        
    } catch (error) {
        console.error('Auth check error:', error);
        currentUser = null;
        updateUIBasedOnAuth(false);
    }
}

function updateUIBasedOnAuth(isAuthenticated) {
    // Hide sensitive buttons if not authenticated
    const addPlaylistBtn = document.getElementById('add-playlist-btn');
    const recordBtn = document.getElementById('record-btn');
    const recordingsBtn = document.getElementById('recordings-btn');
    const logoutBtn = document.getElementById('logout-btn');
    
    if (addPlaylistBtn) addPlaylistBtn.style.display = isAuthenticated ? 'flex' : 'none';
    if (recordBtn) recordBtn.style.display = isAuthenticated ? 'flex' : 'none';
    if (recordingsBtn) recordingsBtn.style.display = isAuthenticated ? 'flex' : 'none';
    if (logoutBtn) logoutBtn.style.display = isAuthenticated ? 'flex' : 'none';
}

function requireAuth() {
    if (!currentUser) {
        alert('Please login to access this feature');
        window.location.href = '/login.html';
        return false;
    }
    
    if (currentUser.must_change_password) {
        alert('Please change your password first');
        window.location.href = '/change-password.html';
        return false;
    }
    
    return true;
}

// Login form handler
if (document.getElementById('login-form')) {
    document.getElementById('login-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        try {
            const response = await fetch(`${API_BASE}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ username, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                if (data.user.must_change_password) {
                    window.location.href = '/change-password.html';
                } else {
                    window.location.href = '/';
                }
            } else {
                showAlert(data.error || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            showAlert('Login failed. Please try again.', 'error');
        }
    });
}

// Change password form handler
if (document.getElementById('change-password-form')) {
    document.getElementById('change-password-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const currentPassword = document.getElementById('current-password').value;
        const newPassword = document.getElementById('new-password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        
        if (newPassword !== confirmPassword) {
            showAlert('New passwords do not match', 'error');
            return;
        }
        
        try {
            const response = await fetch(`${API_BASE}/auth/change-password`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ 
                    current_password: currentPassword,
                    new_password: newPassword
                })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                alert('Password changed successfully!');
                window.location.href = '/';
            } else {
                showAlert(data.error || 'Password change failed', 'error');
            }
        } catch (error) {
            console.error('Password change error:', error);
            showAlert('Password change failed. Please try again.', 'error');
        }
    });
}

// Logout handler
if (document.getElementById('logout-btn')) {
    document.getElementById('logout-btn').addEventListener('click', async () => {
        if (!confirm('Are you sure you want to logout?')) return;
        
        try {
            await fetch(`${API_BASE}/auth/logout`, {
                method: 'POST',
                credentials: 'include'
            });
            
            window.location.href = '/login.html';
        } catch (error) {
            console.error('Logout error:', error);
        }
    });
}

function showAlert(message, type = 'error') {
    const container = document.getElementById('alert-container');
    if (container) {
        container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    }
}

// Run auth check when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', checkAuth);
} else {
    checkAuth();
}
