const API_BASE = '/api';

// Check auth status on page load
async function checkAuth() {
    try {
        const response = await fetch(`${API_BASE}/auth/status`, {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.authenticated) {
            if (data.must_change_password && window.location.pathname !== '/change-password.html') {
                window.location.href = '/change-password.html';
            } else if (!data.must_change_password && window.location.pathname === '/login.html') {
                window.location.href = '/';
            }
        } else {
            if (window.location.pathname !== '/login.html') {
                window.location.href = '/login.html';
            }
        }
    } catch (error) {
        console.error('Auth check error:', error);
    }
}

// Login form handler
if (document.getElementById('login-form')) {
    document.getElementById('login-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        try {
            const response = await fetch(`${API_BASE}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ username, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                if (data.user.must_change_password) {
                    window.location.href = '/change-password.html';
                } else {
                    window.location.href = '/';
                }
            } else {
                showAlert(data.error || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            showAlert('Login failed. Please try again.', 'error');
        }
    });
}

function showAlert(message, type = 'error') {
    const container = document.getElementById('alert-container');
    container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
}

// Run auth check
checkAuth();
