from datetime import datetime
from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Text,
    ForeignKey,
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

# Declarative base
Base = declarative_base()

# SQLAlchemy engine/session globals
_engine = None
_SessionLocal = None

class Playlist(Base):
    __tablename__ = "playlists"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    source_type = Column(String(50), nullable=False)  # url | file
    source_url = Column(Text)                         # when source_type=url
    file_path = Column(Text)                          # when source_type=file
    playlist_type = Column(String(50))                # m3u | m3u8 | xtream | stalker
    user_agent = Column(Text)
    xtream_username = Column(String(255))
    xtream_password = Column(String(255))
    stalker_mac = Column(String(255))
    auto_update = Column(Boolean, default=True)
    last_updated = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    channels = relationship(
        "Channel",
        back_populates="playlist",
        cascade="all, delete-orphan"
    )

class Channel(Base):
    __tablename__ = "channels"

    id = Column(Integer, primary_key=True)
    playlist_id = Column(Integer, ForeignKey("playlists.id"))
    name = Column(String(255), nullable=False)
    group_title = Column(String(255))
    tvg_id = Column(String(255))
    tvg_name = Column(String(255))
    tvg_logo = Column(Text)
    stream_url = Column(Text, nullable=False)

    # catchup/timeshift
    catchup = Column(String(50))
    catchup_source = Column(Text)
    catchup_days = Column(Integer)

    # UX metadata
    is_favorite = Column(Boolean, default=False)
    channel_number = Column(Integer)

    playlist = relationship("Playlist", back_populates="channels")

class EPGSource(Base):
    __tablename__ = "epg_sources"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    url = Column(Text, nullable=False)
    auto_update = Column(Boolean, default=True)
    last_updated = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

def init_db(database_path: str):
    """
    Initialize the SQLite database (creates tables on first run) and
    configure the session factory for use by the API.
    """
    global _engine, _SessionLocal
    if not database_path:
        raise ValueError("DATABASE_PATH is required")

    # check_same_thread=False allows SQLAlchemy sessions in multi-threaded Flask
    _engine = create_engine(
        f"sqlite:///{database_path}",
        connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(_engine)
    _SessionLocal = sessionmaker(bind=_engine, expire_on_commit=False)

def get_session():
    """
    Retrieve a new SQLAlchemy session. Call session.close() after use.
    """
    if _SessionLocal is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    return _SessionLocal()

def update_all_playlists(config: dict):
    """
    Placeholder background job for auto-updating playlists on a schedule.
    Extend this to refresh remote M3U/XC/Stalker sources and update EPGs.
    """
    session = get_session()
    try:
        q = session.query(Playlist).filter(Playlist.auto_update == True).all()
        for p in q:
            # Implement refresh logic per playlist_type here.
            # Keep a simple log for now so container logs show progress.
            print(f"[auto-update] Checked playlist: {p.name}")
        session.commit()
    except Exception as e:
        session.rollback()
        print(f"[auto-update] Error: {e}")
    finally:
        session.close()
from models.user import User, Base as UserBase

def init_db(db_path: str):
    """Initialize database with all tables"""
    engine = create_engine(f"sqlite:///{db_path}")
    
    # Create all tables (existing + User)
    Base.metadata.create_all(engine)
    UserBase.metadata.create_all(engine)
    
    # Create default admin user if doesn't exist
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        admin_user = session.query(User).filter_by(username='admin').first()
        if not admin_user:
            admin = User(
                username='admin',
                is_admin=True,
                must_change_password=True
            )
            admin.set_password('admin123')
            session.add(admin)
            session.commit()
            print("✓ Default admin user created (username: admin, password: admin123)")
            print("⚠ IMPORTANT: Change the default password on first login!")
    except Exception as e:
        print(f"Error creating default admin: {e}")
        session.rollback()
    finally:
        session.close()
    
    return engine
